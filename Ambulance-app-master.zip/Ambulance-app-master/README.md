# 108-Ambulance-app
An android application just like ola/uber where user get located and in case of emergency he can call an ambulance just by pressing 
one button. the location will be send to server and it will automatically inform the nearest free ambulance and also inform his emergency 
contact number.

